package run.halo.app.model.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * Http trace dto.
 *
 * @author johnniang
 * @date 19-6-18
 */
@Data
@ToString
@EqualsAndHashCode
public class HttpTraceDTO {

}
