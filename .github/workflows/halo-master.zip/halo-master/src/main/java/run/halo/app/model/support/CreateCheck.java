package run.halo.app.model.support;

/**
 * Create check for hibernate validation
 *
 * @author johnniang
 * @date 19-4-28
 */
public interface CreateCheck {
}
